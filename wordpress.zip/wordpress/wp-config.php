<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'dcteam_dcteam' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ']@!hTl!o{/,`,)L19xKM7](sg2Ad4Zi4rb`gjDVBsxTA*M;z5i/e<GmGm*H}d@!i' );
define( 'SECURE_AUTH_KEY',  'KSURMdxYQqDPG8EVo8W3f=>K/6>).8B/.oK:ZT*eL%1(oJ(WJjU:)X[wRF)iE<3D' );
define( 'LOGGED_IN_KEY',    'Hv2Gd$%%zh9_$3:v~a_=P|Vvtv^lWH@rX>1fy:A@^Zr XjHOVCKPfsK?Ts`yuK$O' );
define( 'NONCE_KEY',        'XJ+k@7_@C`b`:XGwC!]fnIbQo7bhn6(m@b*r%@I8x%veKg.7%=:S`>i+=HK(UD9#' );
define( 'AUTH_SALT',        'V;?V5aw)TopAgXAeEv,-5_]U*122V)jI[JuK7~$:r8K-iX![(DWPX+4nKpt^/YXt' );
define( 'SECURE_AUTH_SALT', 'nSHA27xnS7iPT CiJ~C^~/>BAm1%>f~m9A!~=Z6bw+<>UE+0$wuArD7(Biwsx3SN' );
define( 'LOGGED_IN_SALT',   'cFJEw|9t@#EVfw,nBvqg *R>M_!MACi7/2E?;L3JK8Eh1F CqA5H+J0Br1)V6j);' );
define( 'NONCE_SALT',       ')|@rL0mH3hF$Q/?bS<VZ:PWi,+O[>?6/c>{}du{MCeTF<*;h4b%]Lg,V2b2Rys+V' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
